# twelve = 4 * 3
# print('twelve =', twelve)

# two = 10 / 5
# print('two =', two) # Выдает 2.0 не тип int 

# Тип type()

# two = 10 / 5 
# print(type(two)) # Выводит тип float()

